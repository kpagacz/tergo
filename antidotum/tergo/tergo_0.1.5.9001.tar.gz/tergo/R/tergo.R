#' A library to make your source code pretty.
#'
#' @keywords internal
"_PACKAGE"


